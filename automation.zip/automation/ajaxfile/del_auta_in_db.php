<?php

session_start();

error_reporting(0);


function isrt_query_db($conn,$isrt_query){


if($conn->query($isrt_query)){

return 1;

}else{
	return $conn->error;
}


}

require("../create/confige/auta_conf.php");

$id=$_SESSION['id'];

$auta_name=$_POST['auta_name'];

$auta_rm_name=base64_decode($auta_name);

  $query = "DELETE FROM auta_name WHERE usr_id='$id' and auta_name='$auta_rm_name'";

  
  if(isrt_query_db($auta_conn,$query)==1){


    unlink("./create/save_auta/".$id."#".$auta_name.".html");

    echo 1;

  }else{


echo 0;

  }





?>