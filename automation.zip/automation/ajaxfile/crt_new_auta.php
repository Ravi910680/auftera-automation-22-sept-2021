<?php

session_start();

$id=$_SESSION['id'];




require("../create/confige/auta_conf.php");



function isrt_query_db($conn,$isrt_query){


if($conn->query($isrt_query)){

return 1;

}else{
	return $conn->error;
}


}



function isrt_auta_name_in_db($conn,$auta_name,$val){



$id=$GLOBALS['id'];

$crt_date=date('d-m-y h:i:s');

$trg_id=0;

$isrt_query="insert into auta_name (usr_id,auta_name,crt_date,trigger_id) values('$id','$auta_name','$crt_date','$trg_id')";

 if(isrt_query_db($conn,$isrt_query)==1){

$myfile = fopen("../create/save_auta/".$id."#".base64_encode($auta_name).".html", "w");

return 1;

}else{

return 0;

}


}



$auta_name=$_POST['auta_name'];

echo isrt_auta_name_in_db($auta_conn,$auta_name,0);

?>