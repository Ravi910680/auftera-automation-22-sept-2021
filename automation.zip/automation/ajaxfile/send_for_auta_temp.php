<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();

$id=$_SESSION['id'];
require("../create/confige/auta_conf.php");







function getValidUrlsFrompage($html)
  {
    $links_ret =array();

//Create a new DOM document
$dom = new DOMDocument;

//Parse the HTML. The @ is used to suppress any parsing errors
//that will be thrown if the $html string isn't valid XHTML.
@$dom->loadHTML($html);

//Get all links. You could also use any other tag name here,
//like 'img' or 'table', to extract other tags.
$links = $dom->getElementsByTagName('a');

//Iterate over the extracted links and display their URLs
foreach ($links as $link){
    //Extract and show the "href" attribute.

$url_dt=$link->getAttribute('href');



if (filter_var($url_dt, FILTER_VALIDATE_URL) !=FALSE) {

    array_push($links_ret,$url_dt );

}


}

    return $links_ret;


}

function url_get_contents ($Url) {
    if (!function_exists('curl_init')){
        die('CURL is not installed!');
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $Url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}

  

function getInbetweenStrings($start, $end, $str){
    $matches = array();
    $regex = "/$start([a-zA-Z0-9_]*)$end/";
    preg_match_all($regex, $str, $matches);
    return $matches[1];
}


$get_temp_id=$_POST['temp_id'];




$html = url_get_contents("https://template.auftera.com/template/crt-template/crtedtemp/".$get_temp_id.".html") or die("Unable to open file!");






$str_arr = getInbetweenStrings('|', '|', $html);





$str_arr=array_unique($str_arr);

foreach ($str_arr as $key => $value) {


$html=str_replace("|".$value."|","<?php echo \$_GET['".$value."'];?>",$html);


}



$links = getValidUrlsFrompage($html);




foreach ($links as $key => $value) {
	
$html=str_replace($value,"http://track-email.auftera.com/auta/click/".$value."",$html);

	
}




$camp_name=$id."^".strtotime("now");

$camp_save_dt_name_db=base64_encode($_POST['name_temp']);

$camp_save_dt_name=$camp_save_dt_name_db.".php";


$insrt_data_int_api_temp_tbl="insert into `auta_temp` (usr_id,temp_id) value ('$id','$camp_save_dt_name_db')";



if($auta_conn->query($insrt_data_int_api_temp_tbl)==TRUE){

$myfile = fopen("../template/".$camp_save_dt_name, "w") or die("Unable to open file!");
$txt = $html;

$open_res_img_tag="<img src='http://track-email.auftera.com/auta/open/<?php echo \$_GET['con_id'];?>/<?php echo \$_GET['auta_name'];?>/<?php echo \$_GET['act_id'];?>/<?php echo \$_GET['usr_id'];?>'>";

fwrite($myfile, $open_res_img_tag);

fwrite($myfile, $txt);
fclose($myfile);





        echo 1;
}else{
               echo 0;
}


?>
