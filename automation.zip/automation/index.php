
<?php
session_start();

$_SESSION['id']="497889959";

$id=$_SESSION['id'];
$email=$_SESSION['email'];

?>






<html><head>


<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1628745601/loader_ww3kdih.css">
<style type="text/css">


.sd-con-ico.dsc-inln-flx {
    width: 8%;
    height: 100%;
}

.main-con-of-crm.dsc-inln-flx {
    width: 92%;
    height: 100%;
    float: right;
    background: #fafafa;
    overflow: scroll;
}

    .dsc-inln-flx {
    display: inline-block;
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

    .icon-con-of-sd {
    height: 90vh;
    width: 100%;
}

.icon-main-con {
    height: auto;
    width: 100%;
    position: relative;
    top: 50%;
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    }

    .con-ico {
    padding: 20px;
    text-align: center;
}

img.con-of-ico-img {
    height: 30px;
    }




.con-of-main-splt {
    width: 20%;
    height: 100vh;
    display: inline-block;

}
.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

   
h2.head-od-dt-shw {
    margin: 0px;
    }


button.btn-of-drk-back {
    height: 6vh;
    width: 100%;
    background: #125ef6;
    border: 0px;
    border-radius: 5px;
    color: white;
}

.con-of-dt-sel-ele {
    height: 80vh;
    width: 100%;
    overflow: scroll;
    }

    .container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 15px;
}
a.com-for-lnk {
    text-decoration: none;
    color: black;
    }

    h2.head-od-dt-shw {
    margin: 0px;
    font-family: lato;
    font-size: 15px;
    font-weight: bolder;
}
.con-of-main-splt {
    width: 20%;
    height: 100vh;
    background: #e5eafc30;
    }


    .eml-add-main-con {
    width: 29%;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    font-size: 16px;
    
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }
    input.srch-ip-fld {
    width: 100%;
    height: 3vh;
    border: none;
    font-family: 'Lato';
    font-weight: 500;
    color: #c7ccd7;
}
.con-of-full-email-dt {
    width: 100%;
    height: 90vh;
    }

    .img-eml-ico-con {
    font-family: 'Lato';
    padding: 15px;
    border-radius: 50%;
    background: pink;
    margin-right: 10px;
    color: #ca1938;
}
.sub-ln-of-email-txt {
    width: 240px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-family: 'Lato';
    color: #908c8c;
    font-size: 13px;
}
input.srch-ip-fld:focus{
    outline: none;
    border: none;
}

    .fnt-ico-sel {
    width: 20px;
    text-align: center;
}

.con-of-cht-usr {
    width: 50%;
    display: inline-block;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    border-left: 1px solid #f2f2f2;
    }





.con-ico:hover{
    cursor: pointer;
}

.head-of-dash{
    background: #4a154b;
    text-align: right;
    border-bottom-left-radius: 50px;
}


.dropdown-menu .dropdown-item {
    padding: .5rem 1rem;
    font-size: 13px;
    font-weight: 600;
}

button.dropdown-item.comm_up_btn:hover {
    background: #0d66d6;
    color: white;
    }

    .dropdown-header {
    padding: .5rem 1rem;
    color: #f6f9fc;
    font-size: .625rem;
    text-transform: uppercase;
    font-weight: 700;
}
.dropdown-header {
    display: block;
    padding: .5rem 1rem;
    margin-bottom: 0;
    font-size: 0.875rem;
    color: #8898aa;
    white-space: nowrap;
    }
    .dropdown-menu {
    padding: 10px !important;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px !important;
}

.dropdown-item {
    border-radius: 10px;
    }

h6, .h6 {
    font-size: 0.625rem !important;
}


.head-of-inn-con {
    padding: 24px;
}
.all-auta-con {
    padding: 0px 24px;
    }
    span.nm-auta-con {
    font-size: 16px;
    font-weight: 500;
    font-family: 'lato';
    color: #00000080;
}

.crt-new-auta-con {
    width: 200px;
    background: rgb(4, 135, 175);
    padding: 24px 16px;
    border-radius: 10px;
    height: 250px;
    margin-right: 30px;
    margin-top: 20px;
}

    .new-crt-head {
    line-height: 28px;
    font-weight: 700;
    color: white;
    font-family: 'Lato';
}
.con-of-crt-new-img {
    text-align: center;
    width: min-content;
    margin-top: 60px;
    padding: 10px;
    margin-left: auto;
    margin-right: auto;
    border-radius: 50%;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
    }

    .crt-new-auta-con:hover{
cursor: pointer;
    }

    .auta-dis-on-dash {
    width: 200px;
    padding: 24px 16px;
    border-radius: 10px;
    background: white;
    margin-right: 30px;
    height: 250px;
    padding-bottom: 0px;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px;
    transition: .3s;
    margin-top: 20px;
}

.auta-dis-on-dash:hover{
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
cursor: pointer;

}
.main-con-name {
    flex: auto;
    min-height: 166px;
    display: inline-grid;
    width: 100%;
    }
    
    span.bdg-tp-btn {
    margin-left: auto;
    font-size: 12px;
    background: rgb(245, 249, 248);
    padding: 2px 10px;
    border-radius: 10px;
    color: rgb(2, 80, 65);
    font-family: 'Lato';
    font-weight: 600;
    letter-spacing: .4px;
    height: fit-content;
}
.def-name-con-crd {
    justify-content: center;
    flex-direction: column;
    display: flex;
    margin: auto;
    font-family: 'Lato';
    }
    .def_stat-of-dt {
    padding: 16px 0px;
    display: inline-flex;
    width: 100%;
    height: 60px;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    
}
    .con-of-cnt-data {
    padding: 5.5px 10px;
    background: rgba(0, 0, 0, 0.07);
    border-radius: 5px;
    color: rgb(38, 38, 39);
    width: 60%;
    text-align: center;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    }

    .con-of-dp-data {
    width: 40%;
}

button#dropdownMenuButton {
    background: no-repeat;
    border: none;
    height: 32px;
    padding: 5.5px;
    float: right;
    }

.all-auta-con {
    padding: 0px 24px;
    display: inline-flex;

}
.dropdown-toggle::after{
    display: none;
}

.dropdown-menu.show{
    border: none;
    border-radius: 10px;
}

a.com-for-lnk {
    text-decoration: none;
    color: #00000091;
    }
    .marg-for-temp{
        margin-left: 0px;
        margin-right: 30px;
    }
    .img-temp-of-mark{
        width: 168px;
        height: 166px;
    }










  .ip-by-def-dsg {
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;


  }

  .ip-by-def-dsg:focus {
    background-color: #fff;
    outline: 0;
    border-color: #524d52;
    box-shadow: 0 0 0 3px #bdb2bd4d;

    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;

  }



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}

.btn-blck-in-auta-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(38, 38, 39);
    color: rgb(255, 255, 255);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
    font-family: 'lato';
}

.btn-blck-in-auta-fcs:hover{
    background-color: rgb(71, 71, 71);
    transition: all 0.2s ease 0s;
}

.btn-blck-non-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(227, 227, 227);
    color: rgb(38, 38, 39);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
}

.btn-blck-non-fcs:hover{
    background-color: rgb(231, 231, 231);
    transition: all 0.2s ease 0s;
    color: black;
}

.modal-content{
    border-radius: 8px;
}

.btn-blck-non-fcs:focus{
    color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;
}
.btn-blck-non-fcs:active{

color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;

}


.con-of-temp-lst {
    display: inline-flex;
    width: 100%;
    padding: 5px 10px;
    border-radius: 10px;
    margin-bottom: 10px;
    }

    .con-of-temp-lst:hover {
    background: #f2f2f28a;
    cursor: pointer;
}

.con-of-temp-lst>div {
    width: 50%;
    }

    span.temp-name {
    font-size: 14px;
}

span.crt-data-of-tmp {
    font-size: 10px;
    }
.row{
    margin-left: 0px;
    margin-right: 0px;
}








.btn-primary.focus, .btn-primary:focus{

    color: #fff;
    box-shadow: 0 0 0 0.2rem rgb(105 109 113 / 50%);
    background-color: rgb(38, 38, 39);
    border-color: rgb(38, 38, 39);

}





.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000b5;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
    z-index: 100000000;
}

#cncl-err-msg:hover{


cursor: pointer;


}



.vert-cent-div {
 
  height: min-content;
  text-align: center;
  
  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;
    
  margin: auto;
}


</style>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>

<body style="
    margin: 0px;
">





<div class="vert-cent-div err-menu-cls-dsg" id="err_msg_dt_trg" style="display: none;">
<span id="con-of-err-msg"></span>
<span class="cls-err-menu" id="cncl-err-msg">
<i class="fal fa-times-circle" style="
    padding: 6px;
"></i>
</span>
</div>


<div class="main-con-of-dash">
<style>


#main-loader-containre-act{


    text-align: center;
    padding-top: 41vh;
  }

.main-loader-containre-act{
  text-align: center;padding-top: 41vh;height: 84vh;
}


.cp-round:after{
        border-top: solid 3px #564f4e;


    }

</style>

<div class="main-con-of-dash">

    
   <?php    require("./confige/header/theme-2.0-side.php");?>
    <div class="main-con-of-crm dsc-inln-flx">
        
 <?php    require("./confige/header/header-new.php");?>

     
<div id='main-loader-containre'>

       
    
 <div class="main-auta-con "  >
    
    <div class="head-of-inn-con">
        <span class="nm-auta-con">My Automation</span>
    
    </div>


<div class="all-auta-con row" id="dyn_con_of_all_auta">

    <div class="crt-new-auta-con" data-toggle="modal" data-target="#crt_new_auta">
        
        <div class="new-crt-head">
        
        New Automation
        </div>
        <div class="con-of-crt-new-img" style="
">
        <svg class="SVGInline-svg" style="width: 14px;height: 14px;fill: rgb(255, 255, 255);" width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M0 6c0-1.10457.89543-2 2-2h8c0 1.10457-.89543 2-2 2H0z"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M6 0v8c0 1.10457-.89543 2-2 2V2c0-1.104569.89543-2 2-2z"></path></svg>
        </div>
    
    
    </div>


    


</div>
    
    
</div>


<div class="auta-temp-name">

<div class="head-of-inn-con">
        <span class="nm-auta-con">Automation Template</span>
    
    </div>


<div class="all-auta-con row" id="all_con_of_temp_data">



<div class="crt-new-auta-con" data-toggle="modal" data-target="#add_temp_in_auta" style="
    background: #8a0f85;
">
        
        <div class="new-crt-head">
        
        New Automation Template
        </div>
        <div class="con-of-crt-new-img" style="
">
        <svg class="SVGInline-svg" style="width: 14px;height: 14px;fill: rgb(255, 255, 255);" width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M0 6c0-1.10457.89543-2 2-2h8c0 1.10457-.89543 2-2 2H0z"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M6 0v8c0 1.10457-.89543 2-2 2V2c0-1.104569.89543-2 2-2z"></path></svg>
        </div>
    
    
    </div>
















</div>


</div>

 












    
    </div>




   


</div>






</div>


<div class="modal" id="crt_new_auta" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">New Automation</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <input type="text" class="ip-by-def-dsg" id="auta-name-con-ip" placeholder="Enter Automation Name">
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="create_new_auta">Create Automation</button>
      </div>
    </div>
  </div>
</div>



<div class="modal" id="giv-temp_auta_name" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none; z-index: 1054; background: rgba(51, 48, 48, 0.52);" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Template Name</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <input type="text" class="ip-by-def-dsg" id="auta_temp_name_def" placeholder="Enter Automation Name">
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="send_temp_for_auta">Create Automation template</button>
      </div>
    </div>
  </div>
</div>





<div class="modal" id="add_temp_in_auta" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content" style="height:60vh;">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Add For Automation</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
</svg>
        </button>
      </div>
      <div class="modal-body" id="app-of-temp-name-data">
    
    
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs"  >Create Automation</button>
      </div>
    </div>
  </div>
</div>



<div class="modal" id="rev_auta_crt" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Revoked Automation</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <input type="text" class="ip-by-def-dsg" id="rev_auta_name_chk" placeholder="Enter REVOKE And Click">
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="rev_btn_auta">Revoke Automation</button>
      </div>
    </div>
  </div>
</div>










<div class="modal" id="del_auta_crt_mdl" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Delete Automation</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <input type="text" class="ip-by-def-dsg" id="del_auta_name_chk" placeholder="Enter DELETE And Click">
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="del_btn_auta">Delete Automation</button>
      </div>
    </div>
  </div>
</div>



















<div class="modal" id="del_temp_mdl" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Delete Template</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <input type="text" class="ip-by-def-dsg" id="del_temp_chk" placeholder="Enter DELETE And Click">
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="del_btn_auta">Delete Template</button>
      </div>
    </div>
  </div>
</div>




















<div class="modal" id="rnm_auta_crt_mdl" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Rename of <span id="rnm-auta-exs-nm"></span></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <input type="text" class="ip-by-def-dsg" id="new-name-of-auta" placeholder="Enter New name">
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="rnm_btn_auta">Rename Automation</button>
      </div>
    </div>
  </div>
</div>



<div class="modal" id="cp_auta_crt_mdl" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Duplicate <span id="cp-auta-exs-nm"></span></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <input type="text" class="ip-by-def-dsg" id="cp-name-of-auta" placeholder="Enter New name">
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="cp_btn_auta">Copy Automation</button>
      </div>
    </div>
  </div>
</div>




</body></html>






<script type="text/javascript">

id='<?php echo $id;?>';










auta_rev_start_name="";




$(document).on("click",".rev_btn_start_mdl",function(){


auta_rev_start_name=$(this).attr("data-targ-auta-id");


})



function rev_auta_in_db_fun(auta_name){


console.log(auta_name);

$.ajax({
                url : "./ajaxfile/rev_auta_in_db.php",
                type: "POST",
                data : {auta_name:auta_name}
        }).done(function(response){ 

if(response==1){

    location.reload();
}


        })


}



//copy automation

cp_auta_id="";


function cp_auta_name_in_db(old_name,new_name){




$.ajax({
                url : "./ajaxfile/copy_auta.php",
                type: "POST",
                data : {old_name:old_name,new_name:new_name}
        }).done(function(response){ 


if(response==1){

    location.reload();
}else{

err_msg_data("Please Enter Valid Name");


}


        })


}


$(document).on('click','.cp_trg_mdl_btn',function(){


cp_auta_id=$(this).attr('data-targ-auta-id');



$("#cp-auta-exs-nm").html(atob(cp_auta_id));



})


$(document).on('click','#cp_btn_auta',function(){



cp_auta_name_in_db(cp_auta_id,$("#cp-name-of-auta").val());


})












//rename javascript automation


rnm_auta_def="";


$(document).on('click','.rnm_trg_mdl_btn',function(){


rnm_auta_def=$(this).attr("data-targ-auta-id");

$("#rnm-auta-exs-nm").html(atob(rnm_auta_def));

})



function rename_auta_name_in_db(old_name,new_name){


console.log(new_name);

$.ajax({
                url : "./ajaxfile/rnm_data_in_db.php",
                type: "POST",
                data : {old_name:old_name,new_name:new_name}
        }).done(function(response){ 


if(response==1){

    location.reload();
}


        })


}

$(document).on('click','#rnm_btn_auta',function(){

nw_name_of_auta=$("#new-name-of-auta").val();



if(nw_name_of_auta.length>0){


rename_auta_name_in_db(rnm_auta_def,nw_name_of_auta);



}


})





//delete autaomation from db nd file

del_auta_id="";

$(document).on('click','.del_start_mdl_btn',function(){

del_auta_id=$(this).attr('data-targ-auta-id');





})





function del_auta_frm_fl(auta_name){



$.ajax({
                url : "./ajaxfile/del_auta_in_db.php",
                type: "POST",
                data : {auta_name:auta_name}
        }).done(function(response){ 

            console.log(response);

if(response==1){

    location.reload();
}


        })


}

$(document).on('click','#del_btn_auta',function(){


console.log($("#del_auta_name_chk").val());

if($("#del_auta_name_chk").val()=="DELETE"){




del_auta_frm_fl(del_auta_id);

}else{


err_msg_data("Enter DELETE As it is");

}


})





$(document).on('click','#rev_btn_auta',function(){




if($("#rev_auta_name_chk").val()=="REVOKE"){



rev_auta_in_db_fun(auta_rev_start_name);

}else{


    err_msg_data("Enter REVOKE As it is");
}


})




$(document).on('click',"#create_new_auta",function(){

auta_name=$("#auta-name-con-ip").val();

console.log(auta_name);

$.ajax({
                url : "./ajaxfile/crt_new_auta.php",
                type: "POST",
                data : {auta_name:auta_name}
        }).done(function(response){ 

if(response==1){



window.location="./create/?auta_id="+btoa(auta_name);

}else{


err_msg_data("Please Enter Valid Name");

}

        })


})


function init_auta_name_dis_str(data){

str_app='';

for(const val of data){


    if(val['status']=="0"){

str_of_act_dt='<div class="con-of-cnt-data">Launch Now</div>';
str_of_dp_con='<div class="dropdown-menu" aria-labelledby="dropdownMenuButton" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(32px, 32px, 0px);"> <a class="dropdown-item " href="./create/?auta_id='+btoa(val['auta_name'])+'">Edit</a> <a class="dropdown-item rnm_trg_mdl_btn" data-toggle="modal" data-target="#rnm_auta_crt_mdl" data-targ-auta-id="'+btoa(val['auta_name'])+'" href="#">Rename</a> <a class="dropdown-item cp_trg_mdl_btn" data-toggle="modal" data-target="#cp_auta_crt_mdl" href="#" data-targ-auta-id="'+btoa(val['auta_name'])+'">Duplicate</a><a class="dropdown-item del_start_mdl_btn" style="color:rgb(140, 3, 3);"  data-toggle="modal" data-target="#del_auta_crt_mdl" href="#" data-targ-auta-id="'+btoa(val['auta_name'])+'">Delete</a>  </div>';

    }else{


str_of_act_dt='<div class="con-of-cnt-data">'+val['cnt_res']+' reach</div>';
str_of_dp_con='<div class="dropdown-menu" aria-labelledby="dropdownMenuButton" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(32px, 32px, 0px);"> <a class="dropdown-item rev_btn_start_mdl" href="#" data-toggle="modal" data-target="#rev_auta_crt" data-targ-auta-id="'+btoa(val['auta_name'])+'">Revoke</a> <a class="dropdown-item " href="#">Reached</a>   </div>';
    }

str_app+='<div class="auta-dis-on-dash"> <div class="main-con-name"> <span class="bdg-tp-btn">Classic</span> <div class="def-name-con-crd">'+val['auta_name']+'</div> </div> <div class="def_stat-of-dt"> '+str_of_act_dt+' <div class="con-of-dp-data" style=""> <div class="dropdown" style=" height: 32px; "> <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <img src="https://res.cloudinary.com/heptera/image/upload/v1621831794/dashboard/more_horiz_black_24dp_kiwldy.svg" class="img-of-act"> </button> '+str_of_dp_con+' </div> </div> </div> </div>';

}

$("#dyn_con_of_all_auta").append(str_app);


}

function init_auta_name_dis(){


$.ajax({
                url : "./ajaxfile/get_all_auta_name.php",
                type: "GET"
                
        }).done(function(response){ 

init_auta_name_dis_str(JSON.parse(response));

        })

}


function init_temp_data_in_mdl(data){

str_app='';


for(const val of data){

temp_name_dis=atob(val['name'].split("^")[1]);

date_dis=new Date(val['dateofcrt']).toUTCString();

str_app+='<div class="con-of-temp-lst add_in_auta_temp" data-temp-name="'+val['name']+'" data-toggle="modal" data-target="#giv-temp_auta_name"> <div class="name-of-temp-data"> <span class="temp-name">'+temp_name_dis+'</span><br> <span class="crt-data-of-tmp">'+date_dis+'</span> </div> <div class="edit-in-editor-btn"> <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal" style=" float: right; ">Open In Editor</button> </div> </div>';


}


$("#app-of-temp-name-data").html(str_app);

}


temp_auta_name="";

$(document).on('click',".add_in_auta_temp",function(){

temp_auta_name=$(this).attr('data-temp-name');







})


$(document).on('click',"#send_temp_for_auta",function(){


def_temp_name=$("#auta_temp_name_def").val();



$.ajax({
                url : "./ajaxfile/send_for_auta_temp.php",
                type: "POST",
                data : {temp_id:temp_auta_name,name_temp:def_temp_name}
        }).done(function(response){ 


		console.log(response);
if(response==1){

location.reload();

}else{

err_msg_data("Please Enter valid Name");

}

        })


})


function init_temp_in_dis_dash(data){

str_app='';


for(const val of data){


name_temp_def=atob(val['temp_id']);

str_app+='<div class="auta-dis-on-dash"> <div class="main-con-name"> <img class="img-temp-of-mark" src="https://scr.auftera.com/scr-api/?url=https://automation.auftera.com/automation/template/'+val['temp_id']+'.php&amp;width=700&amp;height=800"> </div> <div class="def_stat-of-dt"> <div class="con-of-cnt-data">'+name_temp_def+'</div> <div class="con-of-dp-data" style=""> <div class="dropdown" style=" height: 32px; "> <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <img src="https://res.cloudinary.com/heptera/image/upload/v1621831794/dashboard/more_horiz_black_24dp_kiwldy.svg" class="img-of-act"> </button> <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(32px, 32px, 0px);"> <a class="dropdown-item com-for-lnk" data-for-serv="1" data-path-ses="template/" data-target-link="https://template.auftera.com/template/crt-template/" href="#">View </a> <a class="dropdown-item del-temp-mdl-trg" style="color:rgb(140, 3, 3)" data-toggle="modal" data-target="#del_temp_mdl" data-trg-temp-id="'+val['temp_id']+'"    href="#">Delete</a> </div> </div> </div> </div> </div>';
}



$("#all_con_of_temp_data").append(str_app);

}

temp_id_act="";

$(document).on('click','.del-temp-mdl-trg',function(){

temp_id_act=$(this).attr('data-trg-temp-id');

})


function del_temp_auta(temp_id){


$.ajax({
                url : "./ajaxfile/del_auta_temp.php",
                type: "POST",
                data : {temp_id:temp_id}
        }).done(function(response){ 

if(response==1){

location.reload();
}else{

    
}

        })



}


$(document).on('click','#del_btn_auta',function(){


if($("#del_temp_chk").val()=="DELETE"){


del_temp_auta(temp_id_act);

}else{
err_msg_data("Enter DELETE As it is");

}


})

function init_temp_data(){


$.ajax({
    url : './ajaxfile/get-all-temp.php',
    type: 'GET'
  }).done(function(response){

init_temp_in_dis_dash(JSON.parse(response));



  })


}

function init_temp_mdl_data_temp_serve(){


$.ajax({
    url : 'https://template.auftera.com/template/temp_res/gettempdata.php?id='+id,
    type: 'GET'
  }).done(function(response){

init_temp_data_in_mdl(JSON.parse(response));



  })

}




$(document).ready(function(){


$('[data-toggle="tooltip"]').tooltip();

init_auta_name_dis();

init_temp_data();
init_temp_mdl_data_temp_serve();

})








function err_msg_data(message){


$("#con-of-err-msg").html(message);

$("#err_msg_dt_trg").css('display','inline-block');



setTimeout(
    function() {


      $("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');
      
    }, 5000);


}


$(document).on('click','#cncl-err-msg',function(){


$("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');

})

</script>
