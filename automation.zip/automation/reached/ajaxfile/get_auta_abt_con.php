<?php

session_start();
error_reporting(0);
$id=$_SESSION['id'];
require("../../create/confige/auta_conf.php");


function select_query($conn,$sel_query){


	$ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    

    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}

function get_all_con_auta_data($conn,$auta_id,$con_id,$id){

$ret_data=array();

$query="select *from auta_act where usr_id='$id' and auta_name='$auta_id'";

	$res_data=select_query($conn,$query);


	foreach ($res_data as $key => $value) {
$loc_arr=array();

$act_sel_id=$value['blck_id'];


		$sel_qeury="select * from auta_flow where usr_id='$id' and auta_name='$auta_id' and act_id='$act_sel_id' and con_id='$con_id'";

$sel_arr=select_query($conn,$sel_qeury)[0];



$loc_arr['act_date']=$sel_arr['act_date'];
$loc_arr['act_tp']=$value['act_tp'];



array_push($ret_data, $loc_arr);
		
	}



return $ret_data;

}






$auta_id=$_GET['auta_id'];
$con_id=$_GET['con_id'];

echo json_encode(get_all_con_auta_data($auta_conn,$auta_id,$con_id,$id));



?>