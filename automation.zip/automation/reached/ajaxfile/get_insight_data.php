<?php

session_start();
error_reporting(0);
$id=$_SESSION['id'];
require("../../create/confige/auta_conf.php");


function select_query($conn,$sel_query){


	$ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    

    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}


function select_act_start_by_date($conn,$auta_id,$id,$date){


	
$ret_arr=array();

$date_next=gmdate("Y-m-d\TH:i:s\Z", strtotime($date. '+1 day'));

$query="SELECT count(con_id) as count,act_id,avg(act_date) as time FROM `auta_flow` where auta_name='$auta_id' and usr_id='$id' and act_date>'$date' and act_date<'$date_next' and flg_suc='0' group by act_id";



	$res_data=select_query($conn,$query);

foreach ($res_data as $key => $value) {
	
$loc_arr=array();

$loc_arr['reached']=$value['count'];
$loc_arr['blck_id']=$value['act_id'];
$loc_arr['reached_tm']=$value['time'];

$act_id=$value['act_id'];

$query="SELECT count(con_id) as count,act_id,avg(act_date) as time FROM `auta_flow` where auta_name='$auta_id' and usr_id='$id' and act_id='$act_id' and act_date>'$date' and act_date<'$date_next' and flg_suc='1' group by act_id";


	$res_data=select_query($conn,$query)[0];


	$loc_arr['completed']=$res_data['count'];
$loc_arr['blck_id']=$res_data['act_id'];
$loc_arr['comp_tm']=$res_data['time'];

array_push($ret_arr, $loc_arr);

}

	return $ret_arr;




}


function get_all_field_act($conn,$auta_id,$id){
	$query="select *from auta_act where usr_id='$id' and auta_name='$auta_id'";

	$res_data=select_query($conn,$query);

	
foreach ($res_data as $key => $value) {
	
$blck_id=$value['blck_id'];

$query="select count(con_id),avg(act_date) from auta_flow where usr_id='$id' and auta_name='$auta_id' and act_id='$blck_id' and flg_suc='0'";

$res_data[$key]['reached']=select_query($conn,$query)[0]['count(con_id)'];

$query="select count(con_id),avg(act_date) from auta_flow where usr_id='$id' and auta_name='$auta_id' and act_id='$blck_id' and flg_suc='1'";


$sel_sec_data=select_query($conn,$query)[0];

$res_data[$key]['completed']=$sel_sec_data['count(con_id)'];


$date_def=$sel_sec_data['avg(act_date)'];


$res_data[$key]['avg_tm']=$date_def;

}


return $res_data;

}



$auta_id=$_GET['auta_id'];
$res_arr=array();

$res_arr['data']=get_all_field_act($auta_conn,$auta_id,$id);

 $today_cnt_data=select_act_start_by_date($auta_conn,$auta_id,$id,gmdate("Y-m-d\TH:i:s\Z"));

 $yest_cnt_data=select_act_start_by_date($auta_conn,$auta_id,$id,gmdate("Y-m-d\TH:i:s\Z", strtotime(gmdate("Y-m-d\TH:i:s\Z"). '-1 day')));

$res_arr['today_cnt']=$today_cnt_data;
$res_arr['yest_cnt']=$yest_cnt_data;


echo json_encode($res_arr);


?>
