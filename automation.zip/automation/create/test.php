<div class=\"blockelem create-flowy noselect\">
	<input type=\"hidden\" name=\"blockelemtype\" class=\"blockelemtype\" value=\"send_ml_act\">
	<div class=\"grabme\"><img src=\"assets/grabme.svg\"></div>
	<div class=\"blockin\">                  
		<div class=\"blockico\">
			<span></span>
			<img src=\"assets/eye.svg\">
		</div>
		<div class=\"blocktext\">                        
			<p class=\"blocktitle\">Send mail</p>
			<p class=\"blockdesc\">Send particular template that you add for automata</p>        
		</div>
	</div>
</div>


<div class=\"blockelem create-flowy noselect\">
	<input type=\"hidden\" name=\"blockelemtype\" class=\"blockelemtype\" value=\"chg_tg_act\">
	<div class=\"grabme\"><img src=\"assets/grabme.svg\"></div>
	<div class=\"blockin\">                  
		<div class=\"blockico\">
			<span></span>
			<img src=\"assets/eye.svg\">
		</div>
		<div class=\"blocktext\">                        
			<p class=\"blocktitle\">Change tag</p>
			<p class=\"blockdesc\">Change your contact tag when trigger as seted</p>        
		</div>
	</div>
</div>


<div class=\"blockelem create-flowy noselect\">
	<input type=\"hidden\" name=\"blockelemtype\" class=\"blockelemtype\" value=\"crt_arch_act\">
	<div class=\"grabme\"><img src=\"assets/grabme.svg\"></div>
	<div class=\"blockin\">                  
		<div class=\"blockico\">
			<span></span>
			<img src=\"assets/eye.svg\">
		</div>
		<div class=\"blocktext\">                        
			<p class=\"blocktitle\">Create contact archive</p>
			<p class=\"blockdesc\">create contact archived when reached at trigger</p>        
		</div>
	</div>
</div>

<div class=\"blockelem create-flowy noselect\">
	<input type=\"hidden\" name=\"blockelemtype\" class=\"blockelemtype\" value=\"chg_stat_act\">
	<div class=\"grabme\"><img src=\"assets/grabme.svg\"></div>
	<div class=\"blockin\">                  
		<div class=\"blockico\">
			<span></span>
			<img src=\"assets/eye.svg\">
		</div>
		<div class=\"blocktext\">                        
			<p class=\"blocktitle\">Change Status</p>
			<p class=\"blockdesc\">change contact status when triggerd completed</p>        
		</div>
	</div>
</div>

<div class=\"blockelem create-flowy noselect\">
	<input type=\"hidden\" name=\"blockelemtype\" class=\"blockelemtype\" value=\"tm_delay_act\">
	<div class=\"grabme\"><img src=\"assets/grabme.svg\"></div>
	<div class=\"blockin\">                  
		<div class=\"blockico\">
			<span></span>
			<img src=\"assets/eye.svg\">
		</div>
		<div class=\"blocktext\">                        
			<p class=\"blocktitle\">Time Delay</p>
			<p class=\"blockdesc\">Trigger Next action after defined delay time.</p>        
		</div>
	</div>
</div>


<div class=\"blockelem create-flowy noselect\">
	<input type=\"hidden\" name=\"blockelemtype\" class=\"blockelemtype\" value=\"chk_cond_act\">
	<div class=\"grabme\"><img src=\"assets/grabme.svg\"></div>
	<div class=\"blockin\">                  
		<div class=\"blockico\">
			<span></span>
			<img src=\"assets/eye.svg\">
		</div>
		<div class=\"blocktext\">                        
			<p class=\"blocktitle\">Check Condition</p>
			<p class=\"blockdesc\">Check Different condition as per requirnment</p>        
		</div>
	</div>
</div>




<div class=\"blockyleft\"> 
	<img src=\"assets/eyeblue.svg\"> 
	<p class=\"blockyname\">Delete Contact</p> 
</div> <div class=\"blockyright\"> 
<img src=\"assets/more.svg\"> 
</div> 
<div class=\"blockydiv\"> 
</div> 
<div class=\"blockyinfo\">Delete
	<span class=\"data_condition_fld\" data-val-of-opt=\":lst_name:\">Trigger </span> 
	<span class=\"data_compare\" data-val-of-opt=\"choose\">Contact</span> 
	<span class=\"data_collect\" id=\"choose\" data-of-val-sel=\"choose\">Now</span> 
</div>



	
	<div class=\"blockyleft\">
		<img src=\"assets/eyeblue.svg\">
		<p class=\"blockyname\">Add contact</p>
	</div>
	<div class=\"blockyright\">
		<img src=\"assets/more.svg\">
	</div>
	<div class=\"blockydiv\">
	</div>
	<div class=\"blockyinfo\">When a 
		<span>Add In </span> List <span data-of-val-sel="">Site 1</span>
	</div>
