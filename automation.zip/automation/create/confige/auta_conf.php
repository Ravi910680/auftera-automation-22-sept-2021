<?php
$servername = "automation.cqfl2ctd3vqp.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="automation";

$auta_conn = mysqli_connect($servername, $username, $password,$db);

?>


