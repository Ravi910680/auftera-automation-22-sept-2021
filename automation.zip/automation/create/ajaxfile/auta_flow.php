<?php

$servername = "automation.cqfl2ctd3vqp.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="automation";

$auta_conn = mysqli_connect($servername, $username, $password,$db);

function select_query($conn,$sel_query){


	$ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    

    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}


function isrt_query_db($conn,$isrt_query){


if($conn->query($isrt_query)){

return 1;

}else{
	return $conn->error;
}


}

function make_query($data){
$str_app="";
	foreach ($data as $key => $value) {
		$str_app.=$key."='".$value."' and ";
	}

	return substr_replace($str_app ,"", -4);
}






function sel_auta_trg_in_db_isrt($conn,$data_arr,$con_id){

$sel_query="select * from auta_trg where ".make_query($data_arr);





foreach (select_query($conn,$sel_query) as $key => $value) {
	

	$usr_id=$value['usr_id'];
	$auta_name=$value['auta_name'];
	$act_id=$value['act_id'];
	$act_date=gmdate("Y-m-d\TH:i:s\Z");
	$flg_suc=0;

$isrt_query_of_act="insert into auta_flow (usr_id,auta_name,act_id,con_id,act_date,flg_suc) values('$usr_id','$auta_name','$act_id','$con_id','$act_date','$flg_suc')";



isrt_query_db($conn,$isrt_query_of_act);


}




}


if ((!is_array($_POST)) || (count($_POST) < 1)) {
    $_POST = json_decode(file_get_contents('php://input'), true);
}


$data=$_POST;

print_r($data);

$trg_arr=json_decode($data['jsn_arr']);



$con_id=$data['con_id'];

sel_auta_trg_in_db_isrt($auta_conn,$trg_arr,$con_id);


?>
