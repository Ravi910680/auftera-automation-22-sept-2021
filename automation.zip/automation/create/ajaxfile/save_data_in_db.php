<?php
session_start();



$id=$_SESSION['id'];

require("../confige/auta_conf.php");



function isrt_query_db($conn,$isrt_query){


if($conn->query($isrt_query)){

return 1;

}else{
	return $conn->error;
}


}








function isrt_trg_in_db($conn,$auta_name,$arr){

$usr_id=$GLOBALS['id'];

$blck_id=$arr->blck_id;
$trg_tp=$arr->tp;
$fld=$arr->field;
$cmp=$arr->compare;
$data=$arr->data;
$act_id=$arr->act_id;


$isrt_query="insert into auta_trg (usr_id,auta_name,blck_id,trg_tp,field,cmp,data,act_id) values ('$usr_id','$auta_name','$blck_id','$trg_tp','$fld','$cmp','$data','$act_id')";

echo isrt_query_db($conn,$isrt_query);

}


function isrt_auta_name_in_db($conn,$auta_name,$val){



$id=$GLOBALS['id'];

$crt_date=date('d-m-y h:i:s');

$trg_id=$val->blck_id;

$isrt_query="insert into auta_name (usr_id,auta_name,crt_date,trigger_id) values('$id','$auta_name','$crt_date','$trg_id')";

echo isrt_query_db($conn,$isrt_query);


}



function isrt_act_in_db($conn,$auta_name,$arr){



$usr_id=$GLOBALS['id'];

$blck_id=$arr->blck_id;
$trg_tp=$arr->tp;
$fld=$arr->field;
$cmp=$arr->compare;
$data=$arr->data;
$act_id=$arr->act_id;



$isrt_query="insert into auta_act (usr_id,auta_name,blck_id,act_tp,field,cmp,data,act_nxt) values ('$usr_id','$auta_name','$blck_id','$trg_tp','$fld','$cmp','$data','$act_id')";


echo isrt_query_db($conn,$isrt_query);

}


$auta_name=$_POST['auta_name'];
$jsn_data_req=$_POST['jsn_data_str'];



$jsn_dec_data=json_decode($jsn_data_req);














$i=0;

foreach ($jsn_dec_data as $key => $value) {
	

if($i==0){
	



isrt_trg_in_db($auta_conn,$auta_name,$value);

}else{


isrt_act_in_db($auta_conn,$auta_name,$value);

}


	$i+=1;
}














?>