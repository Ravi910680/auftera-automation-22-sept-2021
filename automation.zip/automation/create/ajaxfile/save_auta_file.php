<?php
session_start();
$id=$_SESSION['id'];



$auta_html=$_POST['auta_html'];
$auta_name=$_POST['auta_name'];


$fl_name=$id."#".$auta_name.".html";


unlink("../save_auta/".$fl_name);

$myfile = fopen("../save_auta/".$fl_name, "w") or die("Unable to open file!");



fwrite($myfile, json_encode($auta_html));
fclose($myfile);


?>