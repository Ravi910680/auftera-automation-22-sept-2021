 <?php
session_start();



$auta_name_def=$_GET['auta_id'];
$id=$_SESSION['id'];

 ?>

 <!DOCTYPE html>
<html>
<head>
    <!-- Primary Meta Tags -->
<title>Flowy - The simple flowchart engine</title>
<meta name="title" content="Flowy - The simple flowchart engine">
<meta name="description" content="Flowy is a minimal javascript library to create flowcharts. Use it for automation software, mind mapping tools, programming platforms, and more. Made by Alyssa X.">

<!-- Open Graph / Facebook -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">
<meta property="og:type" content="website">
<meta property="og:url" content="https://alyssax.com/x/flowy">
<meta property="og:title" content="Flowy - The simple flowchart engine">
<meta property="og:description" content="Flowy is a minimal javascript library to create flowcharts. Use it for automation software, mind mapping tools, programming platforms, and more. Made by Alyssa X.">
<meta property="og:image" content="https://alyssax.com/x/assets/meta.png">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="https://alyssax.com/x/flowy">
<meta property="twitter:site" content="alyssaxuu">
<meta property="twitter:title" content="Flowy - The simple flowchart engine">
<meta property="twitter:description" content="Flowy is a minimal javascript library to create flowcharts. Use it for automation software, mind mapping tools, programming platforms, and more. Made by Alyssa X.">
<meta property="twitter:image" content="https://alyssax.com/x/assets/meta.png">
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700&display=swap" rel="stylesheet">
   
    <link href='flowy.min.css' rel='stylesheet' type='text/css'>

    
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">



    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <script src="flowy.min.js"></script>

<link rel="stylesheet" type="text/css" href="../load.css">

    <style type="text/css">

body, html {
    margin: 0px;
    padding: 0px;
    overflow: hidden;
    background-image: url(assets/tile.png);
    background-repeat: repeat;
    background-size: 30px 30px;
    background-color: #FBFBFB;
    height: 100%;
    font-family: 'lato'!important;
}
#navigation {
    height: 71px;
    background-color: #FFF;
    border: 1px solid #E8E8EF;
    width: 100%;
    display: table;
    box-sizing: border-box;
    position: fixed;
    top: 0;
    z-index: 9
}
#back {
    width: 40px;
    height: 40px;
    border-radius: 100px;
    background-color: #F1F4FC;
    text-align: center;
    display: inline-block;
    vertical-align: top;
    margin-top: 12px;
    margin-right: 10px
}
#back img {
    margin-top: 13px;
}
#names {
    display: inline-block;
    vertical-align: top;
}
#title {
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    font-size: 16px;
    color: #393C44;
    margin-bottom: 0px;
}
#subtitle {
    font-family: 'Roboto', sans-serif;
    color: #808292;
    font-size: 14px;
    margin-top: 5px;
}
#leftside {
    display: inline-block;
    vertical-align: middle;
    margin-left: 20px;
}
#centerswitch {
    position: absolute;
    width: 222px;
    left: 50%;
    margin-left: -111px;
    top: 15px;
}
#leftswitch {
    border: 1px solid #E8E8EF;
    background-color: #FBFBFB;
    width: 111px;
    height: 39px;
    line-height: 39px;
    border-radius: 5px 0px 0px 5px;
    font-family: 'Roboto', sans-serif;
    color: #393C44;
    display: inline-block;
    font-size: 14px;
    text-align: center;
}
#rightswitch {
    font-family: 'Roboto', sans-serif;
    color: #808292;
    border-radius: 0px 5px 5px 0px;
    border: 1px solid #E8E8EF;
    height: 39px;
    width: 102px;
    display: inline-block;
    font-size: 14px;
    line-height: 39px;
    text-align: center;
    margin-left: -5px;
}
.discard {
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    font-size: 14px;
    color: #A6A6B3;
    width: 95px;
    height: 38px;
    border: 1px solid #E8E8EF;
    border-radius: 5px;
    text-align: center;
    line-height: 38px;
    display: inline-block;
    vertical-align: top;
    transition: all .2s cubic-bezier(.05,.03,.35,1);
}
.discard:hover {
    cursor: pointer;
    opacity: .7;
}
#publish {
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    font-size: 14px;
    color: #FFF;
    background-color: #611f69;
    border-radius: 5px;
    width: 143px;
    height: 38px;
    margin-left: 10px;
    display: inline-block;
    vertical-align: top;
    text-align: center;
    line-height: 38px;
    margin-right: 20px;
    transition: all .2s cubic-bezier(.05,.03,.35,1);
}
#publish:hover {
    cursor: pointer;
    opacity: .7;
}
#buttonsright {
    float: right;
    margin-top: 15px;
}
#leftcard {
    width: 363px;
    background-color: #FFF;
    border: 1px solid #E8E8EF;
    box-sizing: border-box;
    padding-top: 85px;
    padding-left: 20px;
    height: 100%;
    position: absolute;
    z-index: 2;
}
#search input {
    width: 318px;
    height: 40px;
    background-color: #FFF;
    border: 1px solid #E8E8EF;
    box-sizing: border-box;
    box-shadow: 0px 2px 8px rgba(34,34,87,0.05);
    border-radius: 5px;
    text-indent: 35px;
    font-family: 'Roboto', sans-serif;
    font-size: 16px;
}
::-webkit-input-placeholder { /* Edge */
  color: #C9C9D5;
}

:-ms-input-placeholder { /* Internet Explorer 10-11 */
  color: #C9C9D5
}

::placeholder {
  color: #C9C9D5;
}
#search img {
    position: absolute; 
    margin-top: 10px;
    width: 18px;
    margin-left: 12px;
}
#header {
    font-size: 20px;
    font-family: 'Roboto', sans-serif;
    font-weight: bold;
    color: #393C44;
}
#subnav {
    border-bottom: 1px solid #E8E8EF;
    width: calc(100% + 20px);
    margin-left: -20px;
    margin-top: 10px;
}
.navdisabled {
    transition: all .3s cubic-bezier(.05,.03,.35,1);
}
.navdisabled:hover {
    cursor: pointer;
    opacity: .5;
}
.navactive {
    color: #393C44!important;
}
#triggers {
    margin-left: 20px;
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    font-size: 14px;
    text-align: center;
    color: #808292;
    width: calc(88% / 2);
    height: 48px;
    line-height: 48px;
    display: inline-block;
    float: left;
}
.navactive:after {
    display: block;
    content: "";
    width:  100%;
    height: 4px;
    background-color: #217CE8;
    margin-top: -4px;
}
#actions {
    width: calc(88% / 2);
    display: inline-block;
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    color: #808292;
    font-size: 14px;
    height: 48px;
    line-height: 48px;
    text-align: center;
}
#loggers {
    width: calc(88% / 3);
    display: inline-block;
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    color: #808292;
    font-size: 14px;
    height: 48px;
    line-height: 48px;
    text-align: center;
}
#footer {
    position: absolute;
    left: 0;
    padding-left: 20px;
    line-height: 40px;
    bottom: 0;
    width: 362px;
    border: 1px solid #E8E8EF;
    height: 67px;
    box-sizing: border-box;
    background-color: #FFF;
    font-family: 'Roboto', sans-serif;
    font-size: 14px;
}
#footer a {
    text-decoration: none;
    color: #393C44;
    transition: all .2s cubic-bezier(.05,.03,.35,1);
}
#footer a:hover {
    opacity: .5;
}
#footer span {
    color: #808292;
}
#footer p {
    display: inline-block;
    color: #808292;
}
#footer img {
    margin-left: 5px;
    margin-right: 5px;
}
.blockelem:first-child {
    margin-top: 20px
}
.blockelem {
    padding-top: 10px;
    width: 318px;
    border: 1px solid transparent;
    transition-property: box-shadow, height;
    transition-duration: .2s;
    transition-timing-function: cubic-bezier(.05,.03,.35,1);
    border-radius: 5px;
    box-shadow: 0px 0px 30px rgba(22, 33, 74, 0);
    box-sizing: border-box;
}
.blockelem:hover {
    box-shadow: 0px 4px 30px rgba(22, 33, 74, 0.08);
    border-radius: 5px;
    background-color: #FFF;
    cursor: pointer;
}
.grabme, .blockico {
    display: inline-block;
}
.grabme {
    margin-top: 10px;
    margin-left: 10px;
    margin-bottom: -14px;
    width: 15px;
}
#blocklist {
    height: calc(100% - 220px);
    overflow: auto;
}
#proplist {
    height: calc(100% - 305px);
    overflow: auto;
    margin-top: -30px;
    padding-top: 30px;
}
.blockin {
    display: inline-block;
    vertical-align: top;
    margin-left: 12px;
}
.blockico {
    width: 36px;
    height: 36px;
    
    border-radius: 5px;
    text-align: center;
    white-space: nowrap;
}
.blockico span {
    
    vertical-align: middle;
}
.blockico img {
    height: 36px;
    vertical-align: middle;
    margin-left: auto;
    margin-right: auto;
    display: inline-block;
}
.blocktext {
    display: inline-block;
    width: 220px;
    vertical-align: top;
    margin-left: 12px
}
.blocktitle {
    margin: 0px!important;
    padding: 0px!important;
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    font-size: 16px;
    color: #393C44;
}
.blockdesc {
    margin-top: 5px;
    font-family: 'Roboto', sans-serif;
    color: #808292;
    font-size: 14px;
    line-height: 21px;
}
.blockdisabled {
    background-color: #F0F2F9;
    opacity: .5;
}
#closecard {
    position: absolute;
    margin-left: 340px;
    background-color: #FFF;
    border-radius: 0px 5px 5px 0px;
    border-bottom: 1px solid #E8E8EF;
    border-right: 1px solid #E8E8EF;
    border-top: 1px solid #E8E8EF;
    width: 53px;
    height: 53px;
    text-align: center; 
    z-index: 10;
}
#closecard img {
    margin-top: 15px
}
#canvas {
    position: absolute;
    width: calc(100% - 361px);
    height: calc(100% - 71px);
    top: 71px;
    left: 361px;
    z-index: 0;
    overflow: auto;
}
#propwrap {
    position: absolute;
    right: 0;
    top: 0;
    width: 311px;
    height: 80vh;
    padding-left: 20px;
    overflow: hidden;
    z-index: -2;
    margin-top: 15vh;
    margin-right: 20px;
    border-radius: 40px;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
}

#properties {
    position: absolute;
    height: 100%;
    width: 311px;
    background-color: #FFF;
    right: -150px;
    opacity: 0;
    z-index: 2;
    top: 0px;
    padding-left: 20px;

}
.itson {
    z-index: 2!important;
}
.expanded {
    right: 0!important;
    opacity: 1!important;
    box-shadow: -4px 0px 40px rgba(26, 26, 73, 0.05);
        z-index: 2;
}
#header2 {
    font-size: 20px;
    font-family: 'Roboto', sans-serif;
    font-weight: bold;
    color: #393C44;
    margin-top: 30px;
}
#close {
    margin-top: 30px;
    position: absolute;
    right: 20px;
    z-index: 9999;
    transition: all .25s cubic-bezier(.05,.03,.35,1);
}
#close:hover {
    cursor: pointer;
    opacity: .7;
}
#propswitch {
    border-bottom: 1px solid #E8E8EF;
    width: 331px;
    margin-top: 10px;
    margin-left: -20px;
    margin-bottom: 30px;
}
#dataprop {
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    font-size: 14px;
    text-align: center;
    color: #393C44;
    width: calc(88% / 3);
    height: 48px;
    line-height: 48px;
    display: inline-block;
    float: left;
    margin-left: 20px;
}
#dataprop:after {
    display: block;
    content: "";
    width: 100%;
    height: 4px;
    background-color: #217CE8;
    margin-top: -4px;
}
#alertprop {
    display: inline-block;
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    color: #808292;
    font-size: 14px;
    height: 48px;
    line-height: 48px;
    width: calc(88% / 3);
    text-align: center;
    float: left;
}
#logsprop {
    width: calc(88% / 3);
    display: inline-block;
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    color: #808292;
    font-size: 14px;
    height: 48px;
    line-height: 48px;
    text-align: center;
}
.inputlabel {
    margin-left: 3px;
    font-family: 'Roboto', sans-serif;
    font-size: 14px;
    color: #253134;
}
.dropme {
    background-color: #FFF;
    border-radius: 5px;
    border: 1px solid #E8E8EF;
    box-shadow: 0px 2px 8px rgba(34, 34, 87, 0.05);
    font-family: 'Roboto', sans-serif;
    font-size: 14px;
    color: #253134;
    text-indent: 20px;
    height: 40px;
    line-height: 40px;
    width: 287px;
    margin-bottom: 25px;
}
.dropme img {
    margin-top: 17px;
    float: right;
    margin-right: 15px;
}
.checkus {
    margin-bottom: 10px;
}
.checkus img {
    display: inline-block;
    vertical-align: middle;
}
.checkus p {
    display: inline-block;
    font-family: 'Roboto', sans-serif;
    font-size: 14px;
    vertical-align: middle;
    margin-left: 10px;
}
#divisionthing {
    height: 1px;
    width: 100%;
    background-color: #E8E8EF;
    position: absolute;
    right: 0px;
    bottom: 80;
}
#removeblock {
    border-radius: 5px;
    position: absolute;
    bottom: 20px;
    font-family: 'Roboto', sans-serif;
    font-size: 14px;
    text-align: center;
    width: 287px;
    height: 38px;
    line-height: 38px;
    color: #253134;
    border: 1px solid #E8E8EF;
    transition: all .3s cubic-bezier(.05,.03,.35,1);
}
#removeblock:hover {
    cursor: pointer;
    opacity: .5;
}
.noselect {
  -webkit-touch-callout: none; /* iOS Safari */
    -webkit-user-select: none; /* Safari */
     -khtml-user-select: none; /* Konqueror HTML */
       -moz-user-select: none; /* Old versions of Firefox */
        -ms-user-select: none; /* Internet Explorer/Edge */
            user-select: none; /* Non-prefixed version, currently
                                  supported by Chrome, Opera and Firefox */
}
.blockyname {
    font-family: 'Roboto', sans-serif;
    font-weight: 500;
    color: #253134;
    display: inline-block;
    vertical-align: middle;
    margin-left: 8px;
    font-size: 16px;
}
.blockyleft img {
    display: inline-block;
    vertical-align: middle;
}
.blockyright {
    display: inline-block;
    float: right;
    vertical-align: middle;
    margin-right: 20px;
    margin-top: 10px;
    width: 28px;
    height: 28px;
    border-radius: 5px;
    text-align: center; 
    background-color: #FFF;
    transition: all .3s cubic-bezier(.05,.03,.35,1);
    z-index: 10;
}
.blockyright:hover {
    background-color: #F1F4FC;
    cursor: pointer;
}
.blockyright img {
    margin-top: 12px;
}
.blockyleft {
    display: inline-block;
    margin-left: 20px;
}
.blockydiv {
    width: 100%;
    height: 1px;
    background-color: #E9E9EF;
}
.blockyinfo {
    font-family: 'Roboto', sans-serif;
    font-size: 14px;
    color: #808292;
    margin-top: 15px;
    text-indent: 20px;
    margin-bottom: 20px;
}
.blockyinfo span {
    color: #253134;
    font-weight: 500;
    display: inline-block;
   
    line-height: 20px;
    text-indent: 0px;
}
.block {
    background-color: #FFF;
    margin-top: 0px!important;
    box-shadow: 0px 4px 30px rgba(22, 33, 74, 0.05);
}
.selectedblock {
    border: 2px solid #217CE8 !important;
    box-shadow: 0px 4px 30px rgba(22, 33, 74, 0.08);
}

@media only screen and (max-width: 832px) {
    #centerswitch {
        display: none;
    }
}
@media only screen and (max-width: 560px) {
    #names {
        display: none;
    }   
}



.pro-dis-none{
    display: none;
}





.ip-by-def-dsg{
    width: 90%;
    background-color: #FFFFFF;
    
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    
    border: 1px solid #B8B8B8;
    font-weight: 400;
    
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: rgba(0, 0, 0, 0.12) 0px 1px 3px, rgba(0, 0, 0, 0.24) 0px 1px 2px;
    text-overflow: ellipsis;
    overflow: hidden;
margin-bottom: 10px;
margin-left: 3px;
font-family: 'Roboto';
}

.ip-by-def-dsg:focus{
    background-color: #fff;
    outline: 0;
    border-color: #4a154b;
    box-shadow: 0 0 0 3px #4a154b4d;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    cursor: pointer;
}
.ip-by-def-dsg:hover{
    cursor: pointer;
}

select {

  /* styling */
  background-color: white;
  border: thin solid blue;
  border-radius: 4px;
  display: inline-block;
  font: inherit;
  line-height: 1.5em;
  padding: 0.5em 3.5em 0.5em 1em;
height: auto;
  /* reset */

  margin: 0;      
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  -webkit-appearance: none;
  -moz-appearance: none;
}
select.round {
  background-image:
    linear-gradient(45deg, transparent 50%, gray 50%),
    linear-gradient(135deg, gray 50%, transparent 50%),
    radial-gradient(#ddd 70%, transparent 72%);
  background-position:
    calc(100% - 20px) calc(1em + 2px),
    calc(100% - 15px) calc(1em + 2px),
    calc(100% - .5em) .5em;
  background-size:
    5px 5px,
    5px 5px,
    1.5em 1.5em;
  background-repeat: no-repeat;
}

select.round:focus {
  background-image:
    linear-gradient(45deg, white 50%, transparent 50%),
    linear-gradient(135deg, transparent 50%, white 50%),
    radial-gradient(gray 70%, transparent 72%);
  background-position:
    calc(100% - 15px) 1em,
    calc(100% - 20px) 1em,
    calc(100% - .5em) .5em;
  background-size:
    5px 5px,
    5px 5px,
    1.5em 1.5em;
  background-repeat: no-repeat;
  border-color: green;
  outline: 0;
}




.not-fd-data {
    text-align: center;
    border-radius: 4px;
    padding: 20px;
}

.txt-not-fd {
    padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
    font-size: 10px;
    max-width: 50%;
    }

    .bottom-btn {
    text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}





.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000b5;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
    z-index: 100000000;
}

#cncl-err-msg:hover{


cursor: pointer;


}



.vert-cent-div {
 
  height: min-content;
  text-align: center;
  
  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;
    
  margin: auto;
}


.load-of-main-dash {
    height: 100vh;
    width: 100%;
    position: absolute;
    background: white;
    z-index: 10;
    opacity: .5;
    text-align: center;
   
}


.cp-round:after{
        border-top: solid 3px #564f4e;


    }

    .cp-spinner.cp-round {
    margin-top: 20px;
}
    </style>
   
</head>
<body>


<div class="load-of-main-dash">


<div class="cp-spinner cp-round" style="
    top: 50%;
"></div>

</div>


<div class="vert-cent-div err-menu-cls-dsg" id="err_msg_dt_trg" style="display: none;">
<span id="con-of-err-msg"></span>
<span class="cls-err-menu" id="cncl-err-msg">
<i class="fal fa-times-circle" style="
    padding: 6px;
"></i>
</span>
</div>




    <div id="navigation">
        <div id="leftside">
            <div id="details">
                <div id="names">
                <img src="https://res.cloudinary.com/heptera/image/upload/v1611850905/landing/open-collective_1_m4opwf.svg" style="
    margin-top: 12px;
    height: 40px;
">
            </div>

            
            
        </div>            
        </div>
        <div id="centerswitch">
            <div id="leftswitch" style="width:100%;border-radius:10px;">Automation Dashboard</div>
            
        </div>
        <div id="buttonsright">
            <div class="discard" id='save_auta_in_fl'>Save</div>
            <div class='output_auta' id="publish">Launch Automation</div>
        </div>
    </div>
    <div id="leftcard">
        
        <p id="header">Activity</p>
        
        <div id="subnav">
            <div id="triggers" class="navactive side">Triggers</div>
            <div id="actions" class="navdisabled side">Actions</div>

            
        </div>
       


        <div id="blocklist">
            





        </div>



        
    </div>



    <div id="propwrap">


        <div id="properties">
            <div id="close">
                <img src="assets/close.svg">
            </div>
            <p id="header2">Properties</p>
            


        <div class="pro-dis-none" data-of-prop-con='add_con_trg'>
            <div id="proplist">
                
            </div>

        </div>
        <div class="pro-dis-none" data-of-prop-con='chg_tag_trg'>
            <div id="proplist">
                
            </div>

        </div>
        <div class="pro-dis-none" data-of-prop-con='up_con_trg'>
            <div id="proplist">
                
            </div>

        </div>
        <div class="pro-dis-none" data-of-prop-con='arch_con_trg'>
            <div id="proplist">
                
            </div>

        </div>

        <div class="pro-dis-none" data-of-prop-con='opn_ml_trg'>
            <div id="proplist">
                
            </div>

        </div>
        <div class="pro-dis-none" data-of-prop-con='clck_ml_trg'>
            <div id="proplist">
                
            </div>

        </div>
        <div class="pro-dis-none" data-of-prop-con='chg_stat_trg'>
            <div id="proplist">
                
            </div>

        </div>

         <div class="pro-dis-none" data-of-prop-con='chk_cond_act'>
            <div id="proplist">
                
            </div>

        </div>

        <div class="pro-dis-none" data-of-prop-con='send_ml_act'>
            <div id="proplist">
                
            </div>

        </div>

        <div class="pro-dis-none" data-of-prop-con='chg_tg_act'>
            <div id="proplist">
                
            </div>

        </div>

        <div class="pro-dis-none" data-of-prop-con='crt_arch_act'>
            <div id="proplist">
                
            </div>

        </div>

        <div class="pro-dis-none" data-of-prop-con='chg_stat_act'>
            <div id="proplist">
                
            </div>

        </div>


        <div class="pro-dis-none" data-of-prop-con='tm_delay_act'>
            <div id="proplist">
                
            </div>

        </div>


        <div class="pro-dis-none" data-of-prop-con='del_con_arch'>
            <div id="proplist">
                
            </div>

        </div>


            <div id="divisionthing"></div>
            <div id="removeblock">Delete blocks</div>
        </div>



    </div>
    <div id="canvas">


    

</div>
</body>
</html>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script type="text/javascript">

 
 jsn_pars_data={};








 

lst_name_def="";

auta_name_def_js='<?php echo $auta_name_def;?>';

id_def='<?php echo $id;?>';






init_prop_tp_jsn_data();

function init_prop_tp_jsn_data(){


$.ajax({
                url : "./jsonfile/jsn_for_prop.php?usr_id="+id_def,
                type: "GET"
        }).done(function(response){ 


jsn_pars_data=JSON.parse(response);
console.log(jsn_pars_data);


$(".load-of-main-dash").css('display','none');

        })


}
document.addEventListener("DOMContentLoaded", function(){

   flg_of_trg_act=0;
data_of_blc_arr=[];
data_of_dp_blc=[];



   

    var rightcard = false;
    var tempblock;
    var tempblock2;
    
    flowy(document.getElementById("canvas"), drag, release, snapping);
    function addEventListenerMulti(type, listener, capture, selector) {
        var nodes = document.querySelectorAll(selector);
        for (var i = 0; i < nodes.length; i++) {
            nodes[i].addEventListener(type, listener, capture);
        }
    }
    function snapping(drag, first) {

        console.log(drag);
        var grab = drag.querySelector(".grabme");
        grab.parentNode.removeChild(grab);
        var blockin = drag.querySelector(".blockin");
        blockin.parentNode.removeChild(blockin);
       

       val_of_dp_con=drag.querySelector(".blockelemtype").value;
            drag.innerHTML += data_of_dp_blc[val_of_dp_con];

            if(val_of_dp_con.substr(val_of_dp_con.length-3)=="trg"){

flg_of_trg_act=0;
                add_blc_in_aut("actions");
                $("#actions").addClass("navactive");
                $("#actions").removeClass("navdisabled");
                $("#triggers").addClass('navdisabled');
                $("#triggers").removeClass('navactive');


            }
        return true;
    }
    function drag(block) {



        block.classList.add("blockdisabled");
        tempblock2 = block;
    }
    function release() {





        if (tempblock2) {


            tempblock2.classList.remove("blockdisabled");
	}
	close_prop_data();
    }







    var disabledClick = function(){

        console.log(flg_of_trg_act);

       
    }
     function close_prop_data(){

        console.log("runrunrunrurnrunrrunrur");

        if (rightcard) {
           rightcard = false;
           document.getElementById("properties").classList.remove("expanded");
           setTimeout(function(){
                document.getElementById("propwrap").classList.remove("itson"); 
           }, 300);
            tempblock.classList.remove("selectedblock");
       }
    }
    addEventListenerMulti("click", disabledClick, false, ".side");
    document.getElementById("close").addEventListener("click", function(){
        
        close_prop_data();
    });
    
document.getElementById("removeblock").addEventListener("click", function(){

    flg_of_trg_act=1;

    add_blc_in_aut("triggers");
                $("#triggers").addClass("navactive");
                $("#triggers").removeClass("navdisabled");
                $("#actions").addClass('navdisabled');
                $("#actions").removeClass('navactive');
 flowy.deleteBlocks();
});
var aclick = false;
var noinfo = false;
var beginTouch = function (event) {
    aclick = true;
    noinfo = false;
    if (event.target.closest(".create-flowy")) {
        noinfo = true;
    }
}
var checkTouch = function (event) {
    aclick = false;
}










var doneTouch = function (event) {



 
    if (event.type === "mouseup" && aclick && !noinfo) {
      if (!rightcard && event.target.closest(".block") && !event.target.closest(".block").classList.contains("dragging")) {
            tempblock = event.target.closest(".block");
            rightcard = true;
            

            show_prop_of_sel_blc($(tempblock).children(".blockelemtype").val());
            document.getElementById("properties").classList.add("expanded");
            document.getElementById("propwrap").classList.add("itson");
            tempblock.classList.add("selectedblock");
       } 
    }
}
addEventListener("mousedown", beginTouch, false);
addEventListener("mousemove", checkTouch, false);
addEventListener("mouseup", doneTouch, false);
addEventListenerMulti("touchstart", beginTouch, false, ".block");
});







function init_val_in_sel_blc(val,txt,sel){

sel_of_trg="."+sel;


$(".selectedblock").find(sel_of_trg).attr("data-val-of-opt",val);
$(".selectedblock").find(sel_of_trg).html(txt);

}

arr_of_all_tp=["data_condition_fld","data_compare","data_collect"];




function remove_old_ele(ele_rem_id){

flg=0;
for(const val of arr_of_all_tp){
    if(ele_rem_id==val || flg==0){

flg=1;
continue;

    }else{

init_val_in_sel_blc("choose","choose",val);

        $('div[data-of-prop-con='+data_abtn_mn_fld_sel+']').children("#proplist").children('[data-of-fld-nm='+val+']').prev("p").remove();
        $('div[data-of-prop-con='+data_abtn_mn_fld_sel+']').children("#proplist").children('[data-of-fld-nm='+val+']').remove();
    }
}


}









function find_id_ele_tp(full_data,find_id){

    for (var i = 0; i < full_data['blocks'].length; i++) {
        val=full_data['blocks'][i];


console.log(find_id+" find id check");	
        if(val['id']==find_id){ 

		return val;

}

}

}




data_of_dec=['data_condition_fld','data_compare','data_collect'];


function val_sel_field(fld_name,fld_tp){

flg_fnd=0;
for(const val of data_of_dec){

    if(val=="fld_tp" ){

        flg_fnd=1;

        continue;


    }

if(flg_fnd==1){
    sel=$(".selectedblock").children(".blockyinfo").children("."+val);
        sel.attr("data-val-of-opt","choose");
        sel.html("choose");
}


}


if(fld_name==":lst_name:#rec_sent"){


arr_of_op_val=flowy.output();

console.log(find_id_ele_tp(arr_of_op_val,find_id_ele_tp(arr_of_op_val,$(".selectedblock").children(".blockid").val())['parent']));
if(find_id_ele_tp(arr_of_op_val,find_id_ele_tp(arr_of_op_val,$(".selectedblock").children(".blockid").val())['parent'])['data'][0]['value']=="send_ml_act"){


    return true;
}else{


show_prop_of_sel_blc("chk_cond_act");

    err_msg_data("Send Email In Parent node required");
    return false;
}

}else{
    return true;
}

}

function init_trg_lst_data(callback){

i=0;

$('.data_collect').map(function() {


	console.log($(this).attr('data-val-of-opt'));
if(i==0){

lst_name_def=$(this).attr('data-val-of-opt');
console.log(lst_name_def); 

callback(0);
   } 

})



}

$(document).on('change',".chg_val_of_prop",function(){

console.log($(this).val());

trg_app_fld=$(this).attr("data-of-fld-nm");

console.log(trg_app_fld);

data_abtn_mn_fld_sel=$(this).attr('abt_main_fld');




console.log(String(typeof jsn_pars_data[data_abtn_mn_fld_sel][0][$(this).val()])=='object');


obj_fd_or_nt=jsn_pars_data[data_abtn_mn_fld_sel][0][$("option:selected", this).attr('nxt_sel_trg')];


console.log("select filed if"+$(this).val());






if(String(typeof obj_fd_or_nt)=='object' && val_sel_field($(this).val(),trg_app_fld)){
    

    remove_old_ele(trg_app_fld);

    console.log(obj_fd_or_nt);

str_of_app_dt_nw=str_of_ip_fld_of_opt(obj_fd_or_nt[0]);

console.log(str_of_app_dt_nw);


$('div[data-of-prop-con='+data_abtn_mn_fld_sel+']').children("#proplist").append(str_of_app_dt_nw);

}


init_val_in_sel_blc($(this).val(),$("option:selected", this).text(),trg_app_fld);



})


$(document).on('change','.chg_ip_val_in_flw',function(){

console.log($(this).val());

data_of_mn_fld=$(this).attr('data-of-fld-nm');

init_val_in_sel_blc($(this).val(),$(this).val(),data_of_mn_fld);

});


function str_of_ip_fld_of_opt(val_str){


console.log(val_str);

tp_of_fld=val_str['type'];
val_ip_dt_nm=val_str['name'];
data_of_sel_fld=val_str['value'];
name_lbl_sel_dt=val_str['label'];
data_abt_fld=val_str['data_abt_nm_fld'];



str_ret="";



if(tp_of_fld=="select"){




str_ret+="<p class='inputlabel'>"+name_lbl_sel_dt+"</p><select class='chg_val_of_prop ip-by-def-dsg round' abt_main_fld='"+data_abt_fld+"' data-of-fld-nm='"+val_ip_dt_nm+"'><option disabled selected value> -- select an option -- </option>";

if(data_of_sel_fld.length>0){

for (var i = 0; i < data_of_sel_fld.length; i++) {
    str_ret+='<option value="'+data_of_sel_fld[i]['val']+'" nxt_sel_trg="'+data_of_sel_fld[i]["aft_sel_trg"]+'">'+data_of_sel_fld[i]["plc_hold"]+"</option>";
};


str_ret+="</select>";

}else{

str_ret='<div class="not-fd-data"><img src="https://res.cloudinary.com/heptera/image/upload/v1622821285/account/undraw_Accept_request_re_d81h_zf0qze.svg" style="padding:20px;" height="100"><div class="txt-not-fd">There is no data of send email from auftera api throught a any SMTP server.</div><button class="bottom-btn" data-modal-trigger="src_img_modal" id="ip-img-src-api" style="background: #94918d;border: none;box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px, rgba(60, 64, 67, 0.15) 0px 1px 3px 1px;color: black;font-size: 13px;font-weight: 600;float: none;">Read About API</button></div>';

}



}else if(tp_of_fld=="input"){


str_ret="<p class='inputlabel'>"+name_lbl_sel_dt+"</p><input class='chg_ip_val_in_flw ip-by-def-dsg' abt_main_fld='"+data_abt_fld+"' data-of-fld-nm='"+val_ip_dt_nm+"' type='"+data_of_sel_fld[0]['type']+"' placeholder='"+data_of_sel_fld[0]['plc_holder']+"'/>";


}




console.log(str_ret);


return str_ret;




}


function init_con_of_prop_data(nam_tp){



console.log(nam_tp);

for (const val of jsn_pars_data[nam_tp]){


console.log(nam_tp);

str_of_dt_prop=str_of_ip_fld_of_opt(val);



}


$('div[data-of-prop-con='+nam_tp+']').children("#proplist").html(str_of_dt_prop);


}





function show_prop_of_sel_blc(id_of_sel_blc){


$('.pro-dis-none').map(function() {

    $(this).css('display','none');

})

$('div[data-of-prop-con='+id_of_sel_blc+']').css('display','block');

init_con_of_prop_data(id_of_sel_blc);

}



function add_blc_in_aut(id_of_act){




            document.getElementById("blocklist").innerHTML = data_of_blc_arr[id_of_act];
       





        

}

function read_json_of_blc(callback){


$.getJSON("./jsonfile/json_of_blc.json", function(data){
            
            data_of_blc_arr=data;



            $.getJSON("./jsonfile/json_of_drp_data.json", function(data){
            
            data_of_dp_blc=data;
            

        }).fail(function(e){
            console.log(e);
        });
            
            callback(1);
        }).fail(function(e){
            console.log(e);
        });


}


function init_data_of_cnvs_flow(){


console.log(auta_name_def_js);
fl_name=encodeURIComponent(id_def+"#"+auta_name_def_js+".html");

console.log(fl_name);

$.ajax({
    url : './save_auta/'+fl_name+"?rv="+Math.random(),
    type: 'GET'
  ,success: function(response){
       


    if(response.length>0){


setTimeout(function(){ add_blc_in_aut("actions"); }, 100);
                $("#actions").addClass("navactive");
                $("#actions").removeClass("navdisabled");
                $("#triggers").addClass('navdisabled');
                $("#triggers").removeClass('navactive');

		flowy.import(JSON.parse(response));



		
}

   },error: function(request,status,errorThrown) {
        
console.log(status);

    }
   })


  
    
}


$(document).ready(function(){



init_data_of_cnvs_flow();

read_json_of_blc(function(){

add_blc_in_aut("triggers");
 
});




 })


jsn_exp_arr_new_out=[];


function isInArray(value, array) {
  return array.indexOf(value) > -1;
}


function validate_data_is_valid(val_data,blck_id){


if(isInArray("choose",val_data)){


$('.blockid').map(function() {

    if($(this).val()==blck_id){

        console.log("not-data");

$(this).parent(".block").css('border',"2px solid red");



    }

});

return 1;

}


}


arr_of_op_flw=[];



function get_parent_id_of_ele(id_ele){


return arr_of_op_flw['blocks'][id_ele]['parent'];



}


function save_data_in_file_auta_nw(){


$(".load-of-main-dash").css('display','block');

    html_of_auta=flowy.output();

$.ajax({
                url : "./ajaxfile/save_auta_file.php",
                type: "POST",
                data : {auta_html:html_of_auta,auta_name:auta_name_def_js}
        }).done(function(response){ 


$(".load-of-main-dash").css('display','none');
        })

        return 1;

}


$(document).on('click',"#save_auta_in_fl",function(){

console.log(flowy.output());



save_data_in_file_auta_nw()




})




function auta_data_def_now_out(){


	init_trg_lst_data(function(){

i=0;
jsn_exp_arr_new_out={};

$('.blockelem.block').map(function() {


    

loc_arr_psh={};

$(this).css('border',"none");



loc_arr_psh['tp']=$(this).children(".blockelemtype").val();


loc_arr_psh['data']=$(this).find(".data_collect").attr("data-val-of-opt");

loc_arr_psh['field']=$(this).find(".data_condition_fld").attr("data-val-of-opt");


if(loc_arr_psh['field'].search(":lst_name:")>=0){

console.log(lst_name_def.length);




loc_arr_psh['field']=loc_arr_psh['field'].replace(":lst_name:",lst_name_def);

}

loc_arr_psh['compare']=$(this).find(".data_compare").attr("data-val-of-opt");






idx=$(this).css("top").slice(0,-2);


pare_id=get_parent_id_of_ele(i);

loc_arr_psh['blck_id']=pare_id+"#"+$(this).css("top").slice(0,-2);
loc_arr_psh['act_id']=null;




jsn_exp_arr_new_out[i]=loc_arr_psh;

if(pare_id>-1){

jsn_exp_arr_new_out[pare_id]['act_id']=loc_arr_psh['blck_id'];
}

i+=1;

})


	})



return jsn_exp_arr_new_out;

}



function to_valiadte_obj_data(jsn_exp_arr_new_out_loc){

console.log(Object.keys(jsn_exp_arr_new_out_loc).length);

len_of_arr=Object.keys(jsn_exp_arr_new_out_loc).length;

if(len_of_arr>1){
    for (var i = 0; i <len_of_arr ; i++) {

val=jsn_exp_arr_new_out_loc[i];

console.log(val);


    if(validate_data_is_valid([val['field'],val['data'],val['compare']],i)==1){



jsn_exp_arr_new_out_loc=[];


   err_msg_data("Please Select Reqired field");

return 0;

}

    
};
}else{



   err_msg_data("Please Select Action");
    return 0;
}


return 1;

}


function save_data_into_db(req_jsn_data){


console.log(save_data_in_file_auta_nw());

if(save_data_in_file_auta_nw()==1){


$.ajax({
                url : "./ajaxfile/save_data_in_db.php",
                type: "POST",
                data : {auta_name:auta_name_def_js,jsn_data_str:req_jsn_data}
        }).done(function(response){ 

console.log(response);

        })

    }


}


$(document).on('click',".output_auta",function(){


arr_of_op_flw=flowy.output();




jsn_data_send_req=auta_data_def_now_out();




if(to_valiadte_obj_data(jsn_data_send_req)==1 ){




save_data_into_db(JSON.stringify(jsn_data_send_req));

}











})



$(document).on('change','select[abt_main_fld="chk_cond_act"]',function(){




})











function err_msg_data(message){


$("#con-of-err-msg").html(message);

$("#err_msg_dt_trg").css('display','inline-block');



setTimeout(
    function() {


      $("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');
      
    }, 5000);


}


$(document).on('click','#cncl-err-msg',function(){


$("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');

})



</script>
