
<?php



function select_query($conn,$sel_query){


  $ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    

    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}

require("../confige/tag.conf.php");

$id=$_GET['usr_id'];

$tag_arr=array();
$tag_arr_cond=array();
$list_arr=array();
$seg_arr=array();
$temp_arr=array();
$camp_arr=array();
$pro_arr=array();

$tag_tbl="tag".$id;
$select_query="select * from `$tag_tbl`";

foreach(select_query($mngtag,$select_query) as $value){


$loc_obj=array("plc_hold"=>$value['tag'],"val"=>"%".$value['id'].",","aft_sel_trg"=>"all_tag");
array_push($tag_arr_cond, $loc_obj);
unset($loc_obj['aft_sel_trg']);
array_push($tag_arr,$loc_obj);


}



require("../confige/list.conf.php");

$select_query="select * from filedetails where id='$id'";

foreach(select_query($conn2,$select_query) as $value){

$loc_obj=array("plc_hold"=>base64_decode(explode("^", $value['filename'])[1]),"val"=>$value['filename']);

array_push($list_arr,$loc_obj);



}

require("../confige/seg.conf.php");


$select_query="select * from seg_list where id='$id'";

foreach(select_query($seg_conn,$select_query) as $value){

$loc_obj=array("plc_hold"=>$value['seg_name'],"val"=>$value['unq_id']);

array_push($seg_arr, $loc_obj);

}

require("../confige/account.conf.php");

$select_query="select * from sender_data where id='$id'";

foreach(select_query($conn_acc,$select_query) as $value){

$loc_obj=array("plc_hold"=>$value['email'],"val"=>$value['email']."#".$value['name'],"aft_sel_trg"=>"ent_sub_ln");

array_push($pro_arr, $loc_obj);

}


require("../confige/auta_conf.php");

$select_query="select * from auta_temp where usr_id='$id'";
foreach(select_query($auta_conn,$select_query) as $value){

$loc_obj=array("plc_hold"=>base64_decode($value['temp_id']),"val"=>":lst_name:#".$value['temp_id'],"aft_sel_trg"=>"sel_pro_data");

array_push($temp_arr, $loc_obj);
  }


require("../confige/camp_conf.php");
  $select_query='select * from camp_name_tbl where id="'.$id.'" ORDER BY camp_shed_time DESC';


$camp_field_arr=array();
  foreach(select_query($camp_name_conn,$select_query) as $value){



$loc_obj=array("plc_hold"=>explode("^",$value['camp_name'])[1],"val"=>$value['camp_contact_id'],"aft_sel_trg"=>"sel_list_of_camp");

$loc_obj_for_field=array("plc_hold"=>explode("^",$value['camp_name'])[1],"val"=>":lst_name:#".$value['camp_contact_id'],"aft_sel_trg"=>"rec_sent_cond");

array_push($camp_field_arr, $loc_obj_for_field);
array_push($camp_arr, $loc_obj);
  }


$tag_list=json_encode($tag_arr);
$tag_cond_list=json_encode($tag_arr_cond);
$list_list=json_encode($list_arr);
$seg_list=json_encode($seg_arr);
$temp_list=json_encode($temp_arr);
$camp_list=json_encode($camp_arr);
$camp_field_list=json_encode($camp_field_arr);
$camp_field_list=substr($camp_field_list, 1, -1);

$pro_list=json_encode($pro_arr);
?>

{
"add_con_trg":[{
  
"label":"select list",

"type":"select",
"data_abt_nm_fld":"add_con_trg", 
"name":"data_collect",

  "value":<?php echo $list_list;?>
  

   
}],
"chg_tag_trg":[{
  
"label":"select list",

"type":"select",
"data_abt_nm_fld":"chg_tag_trg", 
"name":"data_collect",

  "value":<?php echo $list_list;?>
  

   
}],
"up_con_trg":[{
  
"label":"select list",

"type":"select",
"data_abt_nm_fld":"up_con_trg", 
"name":"data_collect",

  "value":<?php echo $list_list;?>
  

   
}],

"opn_ml_trg":[{
  
"label":"select list",

"type":"select",
"data_abt_nm_fld":"opn_ml_trg", 
"name":"data_compare",

  "value":<?php echo $camp_list;?>,
"sel_list_of_camp":[{

"label":"select list",

"type":"select",
"data_abt_nm_fld":"opn_ml_trg",
"name":"data_collect",

  "value":<?php echo $list_list;?>



}]

   
}],


"clck_ml_trg":[{
  
"label":"select list",

"type":"select",
"data_abt_nm_fld":"clck_ml_trg", 
"name":"data_compare",
  "value":<?php echo $camp_list;?>,
"sel_list_of_camp":[{

"label":"select list",

"type":"select",
"data_abt_nm_fld":"clck_ml_trg",
"name":"data_collect",

  "value":<?php echo $list_list;?>



}]

   
}],
"arch_con_trg":[{
  
"label":"select list",

"type":"select",
"data_abt_nm_fld":"arch_con_trg", 
"name":"data_collect",

  "value":<?php echo $list_list;?>
  

   
}],
"chg_stat_trg":[{
  
"label":"select list",

"type":"select",
"data_abt_nm_fld":"chg_stat_trg", 
"name":"data_collect",

  "value":<?php echo $list_list;?>
  

   
}],


"send_ml_act":[{
  
"label":"Enter rating",

"type":"select",
"data_abt_nm_fld":"send_ml_act", 
"name":"data_condition_fld",

  "value":<?php echo $temp_list;?>,

  "sel_pro_data":[{
  
"label":"select template",

"type":"select",
"data_abt_nm_fld":"send_ml_act", 
"name":"data_compare",

  "value":<?php echo $pro_list;?>
  


  

   
}],
  "ent_sub_ln":[{
  
"label":"Enter rating",

"type":"input",
"data_abt_nm_fld":"send_ml_act", 
"name":"data_collect",

  "value":[{"plc_holder":"Enter rating","type":"text"}]
  

   
}]

  

   
}],








"chk_cond_act":[{
  "label":"select field",
  "name":"data_condition_fld",
  "type":"select",
  "data_abt_nm_fld":"chk_cond_act", 
  "value":[{"plc_hold":"tag","val":":lst_name:#tag","aft_sel_trg":"tag_cond"},{"plc_hold":"segment","val":":lst_name:#seg","aft_sel_trg":"seg_cond"},{"plc_hold":"source","val":":lst_name:#source","aft_sel_trg":"src_cond"},{"plc_hold":"email","val":":lst_name:#email","aft_sel_trg":"eml_cond"},{"plc_hold":"predicted gender","val":":lst_name:#gender_pre","aft_sel_trg":"pre_gend_cond"},{"plc_hold":"contact rating","val":":lst_name:#usr_star","aft_sel_trg":"con_rat_cond"},{"plc_hold":"Recently Send Email","val":":lst_name:#rec_sent","aft_sel_trg":"rec_sent_cond"},<?php echo $camp_field_list;?>],
  "tag_cond":[{
    "label":"select condition",
"name":"data_compare",
"type":"select",
"data_abt_nm_fld":"chk_cond_act", 

  "value":[{"plc_hold":"is","val":"like","aft_sel_trg":"all_tag"},{"plc_hold":"is not","val":"not like","aft_sel_trg":"all_tag"}]
    
    
    }],
    "rec_sent_cond":[{
    "label":"select Action",
"name":"data_compare",
"type":"select",
"data_abt_nm_fld":"chk_cond_act", 

  "value":[{"plc_hold":"is","val":">=","aft_sel_trg":"rec_send_flg"},{"plc_hold":"is not","val":"<","aft_sel_trg":"rec_send_flg"}]
    
    
    }],
    "rec_send_flg":[{
    "label":"select tag",
"name":"data_collect",
"type":"select",
"data_abt_nm_fld":"chk_cond_act", 

  "value":[{"plc_hold":"sent","val":"1","aft_sel_trg":""},{"plc_hold":"open","val":"2","aft_sel_trg":""},{"plc_hold":"click","val":"3","aft_sel_trg":""}]
  
    
    }],
    
    
    "con_rat_cond":[{
      
      "label":"select condition",
"name":"data_compare",
"type":"select",
"data_abt_nm_fld":"chk_cond_act", 

  "value":[{"plc_hold":"Less than","val":"<","aft_sel_trg":"con_rat_coll"},{"plc_hold":"greater than","val":">","aft_sel_trg":"con_rat_coll"},{"plc_hold":"is equal to","val":"=","aft_sel_trg":"con_rat_coll"},{"plc_hold":"not equal to","val":"<>","aft_sel_trg":"con_rat_coll"}]
      
    }],
    
    "con_rat_coll":[{
  
"label":"Enter rating",

"type":"input",
"data_abt_nm_fld":"chk_cond_act", 
"name":"data_collect",

  "value":[{"plc_holder":"Enter rating","type":"number"}]
  

   
}],
    "pre_gend_cond":[{
      
      "label":"select condition",
"name":"data_compare",
"type":"select",
"data_abt_nm_fld":"chk_cond_act", 

  "value":[{"plc_hold":"is","val":"like","aft_sel_trg":"gend_flg"},{"plc_hold":"is not","val":"not like","aft_sel_trg":"gend_flg"}]
      
    }],
    "gend_flg":[{
  
"label":"select gender",

"type":"select",
"data_abt_nm_fld":"chk_cond_act", 
"name":"data_collect",

  "value":[{"plc_hold":"Male","val":"m"},{"plc_hold":"Female","val":"f"}]
  

   
}],
    "eml_cond":[{
      
      "label":"select condition",
"name":"data_compare",
"type":"select",
"data_abt_nm_fld":"chk_cond_act", 

  "value":[{"plc_hold":"is","val":"like","aft_sel_trg":"src_ent"},{"plc_hold":"is not","val":"not like","aft_sel_trg":"src_ent"}]
      
    }],
    "src_cond":[{
      
      "label":"select condition",
"name":"data_compare",
"type":"select",
"data_abt_nm_fld":"chk_cond_act", 

  "value":[{"plc_hold":"is","val":"like","aft_sel_trg":"src_ent"},{"plc_hold":"is not","val":"not like","aft_sel_trg":"src_ent"}]
      
    }],
    "src_ent":[{
      
      "label":"Enter Source",
"name":"data_collect",
"type":"input",
"data_abt_nm_fld":"chk_cond_act", 

  "value":[{"plc_holder":"Enter Source to filter","type":"text"}]
      
    }],
    "seg_cond":[{
      
      "label":"select condition",
"name":"data_compare",
"type":"select",
"data_abt_nm_fld":"chk_cond_act", 

  "value":[{"plc_hold":"is","val":"Like","aft_sel_trg":"seg_list"},{"plc_hold":"is not","val":"not like","aft_sel_trg":"seg_list"}]
      
    }],
    "all_tag":[{
    "label":"select tag",
"name":"data_collect",
"type":"select",
"data_abt_nm_fld":"chk_cond_act", 

  "value":<?php echo $tag_list;?>
  
    
    }],
    "seg_list":[{
    "label":"select segment",
"name":"data_collect",
"type":"select",
"data_abt_nm_fld":"chk_cond_act", 

  "value":<?php echo $seg_list;?>
  
    
    }]
  
}],

"chg_tg_act":[{
  
"label":"select template",

"type":"select",
"data_abt_nm_fld":"chg_tg_act", 
"name":"data_compare",

  "value":[{"plc_hold":"Add tag","val":"add_tg","aft_sel_trg":"all_tag"},{"plc_hold":"Remove tag","val":"rm_tg","aft_sel_trg":"all_tag"}],
  
 
  "all_tag":[{
    "label":"select tag",
"name":"data_collect",
"type":"select",
"data_abt_nm_fld":"chg_tg_act", 

  "value":<?php echo $tag_list;?>
  
    
    }]
  

   
}],

"crt_arch_act":[{
  
"label":"select Archive Status",

"type":"select",
"data_abt_nm_fld":"crt_arch_act", 
"name":"data_collect",

  "value":[{"plc_hold":"Archived","val":"arch"},{"plc_hold":"Un Archived","val":"un_arch"}]
  

   
}],

"chg_stat_act":[{
  
"label":"Select Contact Status",

"type":"select",
"data_abt_nm_fld":"chg_stat_act", 
"name":"data_collect",

  "value":[{"plc_hold":"Un subscribe","val":"2"},{"plc_hold":"Subscribe","val":"1"},{"plc_hold":"non subscribe","val":"3"},{"plc_hold":"Bounced","val":"4"},{"plc_hold":"VIP","val":"5"}]
  

   
}],
"tm_delay_act":[{
  
"label":"Duration",

"type":"select",
"data_abt_nm_fld":"tm_delay_act", 
"name":"data_compare",

  "value":[{"plc_hold":"1","val":"1","aft_sel_trg":"tp_dur"},{"plc_hold":"2","val":"2","aft_sel_trg":"tp_dur"},{"plc_hold":"3","val":"3","aft_sel_trg":"tp_dur"},{"plc_hold":"4","val":"4","aft_sel_trg":"tp_dur"},{"plc_hold":"5","val":"5","aft_sel_trg":"tp_dur"}],
  
  "tp_dur":[{
    "label":"By",
"name":"data_collect",
"type":"select",
"data_abt_nm_fld":"tm_delay_act", 

  "value":[{"plc_hold":"minute","val":"minutes","aft_sel_trg":"none"},{"plc_hold":"hour","val":"hours","aft_sel_trg":"none"},{"plc_hold":"day","val":"days","aft_sel_trg":"none"},{"plc_hold":"month","val":"months","aft_sel_trg":"none"}]
  
    
    }]
  

   
}],

"del_con_arch":[{
  
"label":"Duration",

"type":"select",
"data_abt_nm_fld":"tm_delay_act", 
"name":"data_compare",

  "value":[]
  
  
  

   
}]


  
}


